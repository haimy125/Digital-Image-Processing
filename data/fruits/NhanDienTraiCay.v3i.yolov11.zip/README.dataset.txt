# NhanDienTraiCay > 2025-05-20 4:07pm
https://universe.roboflow.com/xlas-iy2y1/nhandientraicay-6yp2j

Provided by a Roboflow user
License: CC BY 4.0

